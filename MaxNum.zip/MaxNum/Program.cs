﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MaxNum
{
    class Program
    {
        static void Main(string[] args)
        {
            int a = 0, b = 0, c= 0;

            c = a + b;

            Console.WriteLine(c);

        }
    }
}
